package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DawnAmberDark,
    onPrimary = Color(0xFF5A1D00),
    primaryContainer = DawnAmberContainerDark,
    onPrimaryContainer = OnDawnAmberContainerDark,
    secondary = SageTealDark,
    onSecondary = Color(0xFF003739),
    secondaryContainer = SageTealContainerDark,
    onSecondaryContainer = OnSageTealContainerDark,
    tertiary = MorningLavenderDark,
    background = DawnBackgroundDark,
    surface = DawnSurfaceDark,
    surfaceVariant = DawnSurfaceVariantDark,
    outline = DawnOutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = DawnAmberLight,
    onPrimary = Color.White,
    primaryContainer = DawnAmberContainerLight,
    onPrimaryContainer = OnDawnAmberContainerLight,
    secondary = SageTealLight,
    onSecondary = Color.White,
    secondaryContainer = SageTealContainerLight,
    onSecondaryContainer = OnSageTealContainerLight,
    tertiary = MorningLavenderLight,
    background = DawnBackgroundLight,
    surface = DawnSurfaceLight,
    surfaceVariant = DawnSurfaceVariantLight,
    outline = DawnOutlineLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our carefully crafted Dawn & Zen theme
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
