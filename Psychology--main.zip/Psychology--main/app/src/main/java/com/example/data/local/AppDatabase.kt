package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.SyncStatus
import com.example.data.model.TaskCategory
import com.example.data.model.TaskItem
import com.example.data.model.TaskPriority
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [TaskItem::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mindful_tasks_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialMindfulTasks(database.taskDao())
                    }
                }
            }
        }

        suspend fun populateInitialMindfulTasks(dao: TaskDao) {
            val now = System.currentTimeMillis()
            val initialTasks = listOf(
                TaskItem(
                    title = "🌅 Early Morning Box Breathing (5 min)",
                    description = "Centering meditation: 4s inhale, 4s hold, 4s exhale, 4s pause to calm autonomic nervous system.",
                    category = TaskCategory.MEDITATION,
                    priority = TaskPriority.HIGH,
                    durationMinutes = 5,
                    exerciseType = "BREATHING",
                    syncStatus = SyncStatus.SYNCED,
                    createdAtEpochMs = now - 5000,
                    updatedAtEpochMs = now - 5000
                ),
                TaskItem(
                    title = "🧠 Psychological Exercise: 3 Morning Gratitudes",
                    description = "Cognitive grounding: Note three specific things you genuinely appreciate before facing the day.",
                    category = TaskCategory.PSYCHOLOGICAL,
                    priority = TaskPriority.HIGH,
                    durationMinutes = 4,
                    exerciseType = "GRATITUDE_3",
                    syncStatus = SyncStatus.SYNCED,
                    createdAtEpochMs = now - 4000,
                    updatedAtEpochMs = now - 4000
                ),
                TaskItem(
                    title = "💭 Morning Cognitive Reframe & Daily Anchor",
                    description = "Mental agility: Anticipate one potential stressor today and reframe it into a learning opportunity.",
                    category = TaskCategory.PSYCHOLOGICAL,
                    priority = TaskPriority.MEDIUM,
                    durationMinutes = 3,
                    exerciseType = "COGNITIVE_REFRAME",
                    syncStatus = SyncStatus.SYNCED,
                    createdAtEpochMs = now - 3000,
                    updatedAtEpochMs = now - 3000
                ),
                TaskItem(
                    title = "💧 Sunlight & Hydration Routine",
                    description = "Drink 500ml water and get 10 minutes of direct morning sunlight to set circadian rhythm.",
                    category = TaskCategory.MORNING_ROUTINE,
                    priority = TaskPriority.MEDIUM,
                    durationMinutes = 10,
                    syncStatus = SyncStatus.SYNCED,
                    createdAtEpochMs = now - 2000,
                    updatedAtEpochMs = now - 2000
                ),
                TaskItem(
                    title = "🎯 Identify Top 3 Critical Objectives",
                    description = "Clarity exercise: Write down the three non-negotiable needle-movers for your day.",
                    category = TaskCategory.GENERAL,
                    priority = TaskPriority.HIGH,
                    durationMinutes = 5,
                    syncStatus = SyncStatus.SYNCED,
                    createdAtEpochMs = now - 1000,
                    updatedAtEpochMs = now - 1000
                )
            )
            dao.insertTasks(initialTasks)
        }
    }
}
