package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.TaskDao
import com.example.data.model.SyncStatus
import com.example.data.model.TaskCategory
import com.example.data.model.TaskItem
import com.example.data.model.TaskPriority
import com.example.data.sync.NetworkMonitor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class SyncResult(
    val success: Boolean,
    val syncedCount: Int,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

class TaskRepository(
    private val taskDao: TaskDao,
    private val networkMonitor: NetworkMonitor
) {
    val allActiveTasks: Flow<List<TaskItem>> = taskDao.getAllActiveTasks()
    val pendingSyncCount: Flow<Int> = taskDao.getPendingSyncCountFlow()
    val totalCount: Flow<Int> = taskDao.getTotalTasksCountFlow()
    val completedCount: Flow<Int> = taskDao.getCompletedTasksCountFlow()

    suspend fun insertTask(
        title: String,
        description: String,
        category: TaskCategory,
        priority: TaskPriority,
        durationMinutes: Int = 5,
        exerciseType: String? = null
    ): Long = withContext(Dispatchers.IO) {
        val isOnline = networkMonitor.isOnline.value
        val now = System.currentTimeMillis()
        val task = TaskItem(
            title = title,
            description = description,
            category = category,
            priority = priority,
            durationMinutes = durationMinutes,
            exerciseType = exerciseType,
            createdAtEpochMs = now,
            updatedAtEpochMs = now,
            syncStatus = if (isOnline) SyncStatus.SYNCED else SyncStatus.PENDING_SYNC,
            remoteId = UUID.randomUUID().toString()
        )
        taskDao.insertTask(task)
    }

    suspend fun updateTask(task: TaskItem) = withContext(Dispatchers.IO) {
        val isOnline = networkMonitor.isOnline.value
        val updated = task.copy(
            updatedAtEpochMs = System.currentTimeMillis(),
            syncStatus = if (isOnline) SyncStatus.SYNCED else SyncStatus.PENDING_SYNC
        )
        taskDao.updateTask(updated)
    }

    suspend fun toggleTaskCompleted(task: TaskItem) = withContext(Dispatchers.IO) {
        val isOnline = networkMonitor.isOnline.value
        val updated = task.copy(
            isCompleted = !task.isCompleted,
            updatedAtEpochMs = System.currentTimeMillis(),
            syncStatus = if (isOnline) SyncStatus.SYNCED else SyncStatus.PENDING_SYNC
        )
        taskDao.updateTask(updated)
    }

    suspend fun saveExerciseReflection(
        taskId: Long,
        reflection: String,
        markComplete: Boolean = true
    ) = withContext(Dispatchers.IO) {
        val task = taskDao.getTaskById(taskId).first() ?: return@withContext
        val isOnline = networkMonitor.isOnline.value
        val updated = task.copy(
            exerciseReflection = reflection,
            isCompleted = if (markComplete) true else task.isCompleted,
            updatedAtEpochMs = System.currentTimeMillis(),
            syncStatus = if (isOnline) SyncStatus.SYNCED else SyncStatus.PENDING_SYNC
        )
        taskDao.updateTask(updated)
    }

    suspend fun deleteTask(id: Long) = withContext(Dispatchers.IO) {
        val isOnline = networkMonitor.isOnline.value
        if (isOnline) {
            taskDao.hardDeleteTask(id)
        } else {
            // Mark as soft deleted so the deletion can be synchronized when back online
            taskDao.softDeleteTask(id)
        }
    }

    suspend fun syncPendingTasks(): SyncResult = withContext(Dispatchers.IO) {
        val isOnline = networkMonitor.isOnline.value
        if (!isOnline) {
            return@withContext SyncResult(
                success = false,
                syncedCount = 0,
                message = "Device is offline. Changes saved locally in offline queue."
            )
        }

        val pending = taskDao.getPendingSyncTasks()
        if (pending.isEmpty()) {
            return@withContext SyncResult(
                success = true,
                syncedCount = 0,
                message = "All tasks up to date. No pending changes."
            )
        }

        // Simulate network upload/sync latency to give genuine visual feedback
        delay(600)

        val now = System.currentTimeMillis()
        val idsToMark = pending.map { it.id }
        taskDao.markTasksAsSynced(idsToMark, now)
        taskDao.purgeDeletedSyncedTasks()

        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(now))
        SyncResult(
            success = true,
            syncedCount = pending.size,
            message = "Successfully synchronized ${pending.size} item(s) at $timeStr"
        )
    }

    suspend fun restoreDefaultMorningRoutine() = withContext(Dispatchers.IO) {
        AppDatabase.populateInitialMindfulTasks(taskDao)
    }
}
