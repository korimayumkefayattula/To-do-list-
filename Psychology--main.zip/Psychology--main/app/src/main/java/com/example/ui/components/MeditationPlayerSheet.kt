package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.TaskItem
import com.example.util.MeditationSoundHelper
import kotlinx.coroutines.delay

enum class BreathingPhase(val title: String, val instruction: String, val targetScale: Float) {
    INHALE("Inhale", "Breathe in deeply through your nose...", 1.35f),
    HOLD_IN("Hold", "Retain the breath with relaxed posture...", 1.35f),
    EXHALE("Exhale", "Release slowly and let go of tension...", 0.85f),
    HOLD_OUT("Rest", "Rest in pure quiet stillness...", 0.85f)
}

@Composable
fun MeditationPlayerSheet(
    task: TaskItem,
    soundHelper: MeditationSoundHelper,
    onComplete: (taskId: Long) -> Unit,
    onDismiss: () -> Unit
) {
    val totalSeconds = (task.durationMinutes.coerceAtLeast(1)) * 60
    var remainingSeconds by remember { mutableIntStateOf(totalSeconds) }
    var isRunning by remember { mutableStateOf(true) }

    // Box breathing: 4 seconds per phase
    var currentPhase by remember { mutableStateOf(BreathingPhase.INHALE) }
    var phaseSecondsLeft by remember { mutableIntStateOf(4) }
    var breathCyclesCompleted by remember { mutableIntStateOf(0) }

    val circleScale by animateFloatAsState(
        targetValue = if (isRunning) currentPhase.targetScale else 1.0f,
        animationSpec = tween(
            durationMillis = if (currentPhase == BreathingPhase.INHALE || currentPhase == BreathingPhase.EXHALE) 3800 else 400,
            easing = FastOutSlowInEasing
        ),
        label = "breathScale"
    )

    // Timer loop
    LaunchedEffect(isRunning, remainingSeconds) {
        if (isRunning && remainingSeconds > 0) {
            delay(1000)
            remainingSeconds--
            phaseSecondsLeft--

            if (phaseSecondsLeft <= 0) {
                // Transition to next phase in box breathing
                val nextPhase = when (currentPhase) {
                    BreathingPhase.INHALE -> BreathingPhase.HOLD_IN
                    BreathingPhase.HOLD_IN -> BreathingPhase.EXHALE
                    BreathingPhase.EXHALE -> {
                        breathCyclesCompleted++
                        BreathingPhase.HOLD_OUT
                    }
                    BreathingPhase.HOLD_OUT -> BreathingPhase.INHALE
                }
                currentPhase = nextPhase
                phaseSecondsLeft = 4
                soundHelper.playPhaseChime()
            }
        } else if (remainingSeconds <= 0 && isRunning) {
            isRunning = false
            soundHelper.playSessionCompleteBell()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            color = Color(0xFF141920) // Deep calm twilight dark canvas for focus
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Background ambient circular gradient
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(340.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF319795).copy(alpha = 0.25f),
                                    Color(0xFF2B6CB0).copy(alpha = 0.12f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.SelfImprovement,
                                contentDescription = null,
                                tint = Color(0xFF81E6D9),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Early Morning Meditation",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 0.5.sp
                                ),
                                color = Color(0xFFE2E8F0)
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("close_meditation_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close meditation session",
                                tint = Color.White.copy(alpha = 0.7f)
                            )
                        }
                    }

                    // Middle Section: Breathing Halo & Guidance
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = task.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            ),
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Box Breathing 4-4-4-4 • Cycle $breathCyclesCompleted",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF81E6D9)
                        )

                        Spacer(modifier = Modifier.height(40.dp))

                        // Animated breathing concentric circles
                        Box(
                            modifier = Modifier
                                .size(220.dp)
                                .scale(circleScale),
                            contentAlignment = Alignment.Center
                        ) {
                            // Outer ring
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            colors = listOf(
                                                Color(0xFF319795).copy(alpha = 0.45f),
                                                Color(0xFF81E6D9).copy(alpha = 0.15f),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )

                            // Inner circle
                            Box(
                                modifier = Modifier
                                    .size(130.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(
                                                Color(0xFF285E61),
                                                Color(0xFF319795)
                                            )
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = currentPhase.title,
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 22.sp
                                        ),
                                        color = Color.White
                                    )
                                    Text(
                                        text = "${phaseSecondsLeft}s",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color(0xFFE6FFFA)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(36.dp))

                        // Gentle Instruction text
                        Text(
                            text = currentPhase.instruction,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Medium,
                                fontSize = 16.sp
                            ),
                            color = Color(0xFFCBD5E0),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Remaining total time
                        val mins = remainingSeconds / 60
                        val secs = remainingSeconds % 60
                        Text(
                            text = String.format("%02d:%02d", mins, secs),
                            style = MaterialTheme.typography.displaySmall.copy(
                                fontWeight = FontWeight.Light,
                                letterSpacing = 2.sp
                            ),
                            color = Color.White
                        )
                    }

                    // Bottom Controls: Pause/Resume, Finish early
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { isRunning = !isRunning },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color.White
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                                modifier = Modifier.testTag("pause_resume_meditation")
                            ) {
                                Icon(
                                    imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isRunning) "Pause" else "Resume"
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isRunning) "Pause" else "Resume")
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Button(
                                onClick = { onComplete(task.id) },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF319795)
                                ),
                                modifier = Modifier.testTag("complete_meditation_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Complete session"
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Complete Session")
                            }
                        }
                    }
                }
            }
        }
    }
}
