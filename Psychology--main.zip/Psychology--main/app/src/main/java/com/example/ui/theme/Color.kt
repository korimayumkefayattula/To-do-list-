package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dawn & Morning Zen Palette
val DawnAmberLight = Color(0xFFC05621)
val DawnAmberContainerLight = Color(0xFFFFDBCF)
val OnDawnAmberContainerLight = Color(0xFF381000)

val SageTealLight = Color(0xFF285E61)
val SageTealContainerLight = Color(0xFFB2F5EA)
val OnSageTealContainerLight = Color(0xFF002022)

val MorningLavenderLight = Color(0xFF553C9A)
val MorningLavenderContainerLight = Color(0xFFE9D8FD)

val DawnBackgroundLight = Color(0xFFFBF9F5)
val DawnSurfaceLight = Color(0xFFFFFFFF)
val DawnSurfaceVariantLight = Color(0xFFF0ECE1)
val DawnOutlineLight = Color(0xFFE2DDD3)

// Dark Theme Dawn
val DawnAmberDark = Color(0xFFFFB59D)
val DawnAmberContainerDark = Color(0xFF7A2E00)
val OnDawnAmberContainerDark = Color(0xFFFFDBCF)

val SageTealDark = Color(0xFF81E6D9)
val SageTealContainerDark = Color(0xFF1D4044)
val OnSageTealContainerDark = Color(0xFFB2F5EA)

val MorningLavenderDark = Color(0xFFD6BCFA)
val MorningLavenderContainerDark = Color(0xFF322659)

val DawnBackgroundDark = Color(0xFF141413)
val DawnSurfaceDark = Color(0xFF1C1C1A)
val DawnSurfaceVariantDark = Color(0xFF2B2A27)
val DawnOutlineDark = Color(0xFF44433F)

val SyncGreen = Color(0xFF2E7D32)
val SyncAmber = Color(0xFFD97706)
val SyncBlue = Color(0xFF1E88E5)
