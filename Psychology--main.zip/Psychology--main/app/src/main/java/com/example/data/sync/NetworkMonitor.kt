package com.example.data.sync

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NetworkMonitor(context: Context) {
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val _realOnlineStatus = MutableStateFlow(checkInitialConnectivity())
    private val _isSimulatedOffline = MutableStateFlow(false)
    private val _isOnline = MutableStateFlow(_realOnlineStatus.value)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()
    val isSimulatedOffline: StateFlow<Boolean> = _isSimulatedOffline.asStateFlow()

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            _realOnlineStatus.value = true
            updateEffectiveStatus()
        }

        override fun onLost(network: Network) {
            _realOnlineStatus.value = false
            updateEffectiveStatus()
        }

        override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities
        ) {
            val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            _realOnlineStatus.value = hasInternet
            updateEffectiveStatus()
        }
    }

    init {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        try {
            connectivityManager.registerNetworkCallback(request, networkCallback)
        } catch (_: Exception) {
            // Fallback gracefully if permissions or environment restrict
        }
        updateEffectiveStatus()
    }

    private fun checkInitialConnectivity(): Boolean {
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun updateEffectiveStatus() {
        _isOnline.value = if (_isSimulatedOffline.value) false else _realOnlineStatus.value
    }

    fun toggleOfflineSimulation() {
        _isSimulatedOffline.value = !_isSimulatedOffline.value
        updateEffectiveStatus()
    }

    fun setSimulatedOffline(offline: Boolean) {
        _isSimulatedOffline.value = offline
        updateEffectiveStatus()
    }
}
