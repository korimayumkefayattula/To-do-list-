package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.TaskCategory
import com.example.data.model.TaskItem
import com.example.data.model.TaskPriority
import com.example.data.repository.TaskRepository
import com.example.data.sync.NetworkMonitor
import com.example.util.MeditationSoundHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class TaskFilterTab(val label: String) {
    ALL("All Tasks"),
    MORNING("Morning Routine"),
    MINDFULNESS("Meditation & Psy"),
    WORK("Work & General")
}

data class AppUiState(
    val tasks: List<TaskItem> = emptyList(),
    val filteredTasks: List<TaskItem> = emptyList(),
    val selectedFilterTab: TaskFilterTab = TaskFilterTab.ALL,
    val selectedCategory: TaskCategory? = null,
    val searchQuery: String = "",
    val hideCompleted: Boolean = false,
    val isOnline: Boolean = true,
    val isSimulatedOffline: Boolean = false,
    val isSyncing: Boolean = false,
    val pendingSyncCount: Int = 0,
    val totalCount: Int = 0,
    val completedCount: Int = 0,
    val syncLogMessage: String = "Ready for offline synchronization",
    val activeMeditationTask: TaskItem? = null,
    val activePsychologicalTask: TaskItem? = null,
    val showAddTaskDialog: Boolean = false,
    val showSyncDetailsDialog: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val networkMonitor = NetworkMonitor(application)
    val repository = TaskRepository(database.taskDao(), networkMonitor)
    val soundHelper = MeditationSoundHelper(application)

    private val _selectedFilterTab = MutableStateFlow(TaskFilterTab.ALL)
    private val _selectedCategory = MutableStateFlow<TaskCategory?>(null)
    private val _searchQuery = MutableStateFlow("")
    private val _hideCompleted = MutableStateFlow(false)
    private val _isSyncing = MutableStateFlow(false)
    private val _syncLogMessage = MutableStateFlow("All data stored locally in Room database")
    private val _activeMeditationTask = MutableStateFlow<TaskItem?>(null)
    private val _activePsychologicalTask = MutableStateFlow<TaskItem?>(null)
    private val _showAddTaskDialog = MutableStateFlow(false)
    private val _showSyncDetailsDialog = MutableStateFlow(false)

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
    val isSimulatedOffline: StateFlow<Boolean> = networkMonitor.isSimulatedOffline
    val pendingSyncCount: StateFlow<Int> = repository.pendingSyncCount.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        0
    )

    val uiState: StateFlow<AppUiState> = combine(
        repository.allActiveTasks,
        _selectedFilterTab,
        _selectedCategory,
        _searchQuery,
        _hideCompleted,
        networkMonitor.isOnline,
        networkMonitor.isSimulatedOffline,
        _isSyncing,
        repository.pendingSyncCount,
        _syncLogMessage,
        _activeMeditationTask,
        _activePsychologicalTask,
        _showAddTaskDialog,
        _showSyncDetailsDialog
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val tasks = args[0] as List<TaskItem>
        val filterTab = args[1] as TaskFilterTab
        val category = args[2] as TaskCategory?
        val query = (args[3] as String).trim()
        val hideComp = args[4] as Boolean
        val online = args[5] as Boolean
        val simOff = args[6] as Boolean
        val syncing = args[7] as Boolean
        val pendingCount = args[8] as Int
        val syncLog = args[9] as String
        val activeMed = args[10] as TaskItem?
        val activePsy = args[11] as TaskItem?
        val showAdd = args[12] as Boolean
        val showSync = args[13] as Boolean

        val total = tasks.size
        val completed = tasks.count { it.isCompleted }

        val filtered = tasks.filter { task ->
            val matchesTab = when (filterTab) {
                TaskFilterTab.ALL -> true
                TaskFilterTab.MORNING -> task.category == TaskCategory.MORNING_ROUTINE || task.category == TaskCategory.MEDITATION || task.category == TaskCategory.PSYCHOLOGICAL
                TaskFilterTab.MINDFULNESS -> task.category == TaskCategory.MEDITATION || task.category == TaskCategory.PSYCHOLOGICAL
                TaskFilterTab.WORK -> task.category == TaskCategory.WORK || task.category == TaskCategory.GENERAL || task.category == TaskCategory.HEALTH
            }
            val matchesCategory = category == null || task.category == category
            val matchesQuery = query.isEmpty() || task.title.contains(query, ignoreCase = true) || task.description.contains(query, ignoreCase = true)
            val matchesCompleted = !hideComp || !task.isCompleted

            matchesTab && matchesCategory && matchesQuery && matchesCompleted
        }

        AppUiState(
            tasks = tasks,
            filteredTasks = filtered,
            selectedFilterTab = filterTab,
            selectedCategory = category,
            searchQuery = query,
            hideCompleted = hideComp,
            isOnline = online,
            isSimulatedOffline = simOff,
            isSyncing = syncing,
            pendingSyncCount = pendingCount,
            totalCount = total,
            completedCount = completed,
            syncLogMessage = syncLog,
            activeMeditationTask = activeMed,
            activePsychologicalTask = activePsy,
            showAddTaskDialog = showAdd,
            showSyncDetailsDialog = showSync
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        AppUiState()
    )

    init {
        // Automatically synchronize pending changes whenever connectivity is restored
        viewModelScope.launch {
            networkMonitor.isOnline.collect { online ->
                if (online) {
                    syncNow(isAuto = true)
                } else {
                    _syncLogMessage.value = "Working offline. Changes are saved locally."
                }
            }
        }
    }

    fun setFilterTab(tab: TaskFilterTab) {
        _selectedFilterTab.value = tab
    }

    fun setSelectedCategory(category: TaskCategory?) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleHideCompleted() {
        _hideCompleted.value = !_hideCompleted.value
    }

    fun setShowAddTaskDialog(show: Boolean) {
        _showAddTaskDialog.value = show
    }

    fun setShowSyncDetailsDialog(show: Boolean) {
        _showSyncDetailsDialog.value = show
    }

    fun toggleOfflineSimulation() {
        networkMonitor.toggleOfflineSimulation()
    }

    fun toggleTaskCompleted(task: TaskItem) {
        viewModelScope.launch {
            repository.toggleTaskCompleted(task)
            if (networkMonitor.isOnline.value) {
                syncNow(isAuto = true)
            }
        }
    }

    fun addTask(
        title: String,
        description: String,
        category: TaskCategory,
        priority: TaskPriority,
        durationMinutes: Int = 5,
        exerciseType: String? = null
    ) {
        viewModelScope.launch {
            repository.insertTask(
                title = title,
                description = description,
                category = category,
                priority = priority,
                durationMinutes = durationMinutes,
                exerciseType = exerciseType
            )
            _showAddTaskDialog.value = false
            if (networkMonitor.isOnline.value) {
                syncNow(isAuto = true)
            }
        }
    }

    fun deleteTask(id: Long) {
        viewModelScope.launch {
            repository.deleteTask(id)
            if (networkMonitor.isOnline.value) {
                syncNow(isAuto = true)
            }
        }
    }

    fun savePsychologicalReflection(taskId: Long, reflection: String) {
        viewModelScope.launch {
            repository.saveExerciseReflection(taskId, reflection, markComplete = true)
            _activePsychologicalTask.value = null
            soundHelper.playSessionCompleteBell()
            if (networkMonitor.isOnline.value) {
                syncNow(isAuto = true)
            }
        }
    }

    fun completeMeditationSession(taskId: Long) {
        viewModelScope.launch {
            val currentTask = _activeMeditationTask.value ?: return@launch
            repository.saveExerciseReflection(
                taskId,
                currentTask.exerciseReflection ?: "Completed ${currentTask.durationMinutes} min morning meditation session.",
                markComplete = true
            )
            _activeMeditationTask.value = null
            soundHelper.playSessionCompleteBell()
            if (networkMonitor.isOnline.value) {
                syncNow(isAuto = true)
            }
        }
    }

    fun startMeditation(task: TaskItem) {
        _activeMeditationTask.value = task
    }

    fun dismissMeditation() {
        _activeMeditationTask.value = null
    }

    fun startPsychologicalExercise(task: TaskItem) {
        _activePsychologicalTask.value = task
    }

    fun dismissPsychologicalExercise() {
        _activePsychologicalTask.value = null
    }

    fun restoreMorningPack() {
        viewModelScope.launch {
            repository.restoreDefaultMorningRoutine()
            if (networkMonitor.isOnline.value) {
                syncNow(isAuto = true)
            }
        }
    }

    fun syncNow(isAuto: Boolean = false) {
        viewModelScope.launch {
            if (_isSyncing.value) return@launch
            _isSyncing.value = true
            val result = repository.syncPendingTasks()
            _isSyncing.value = false
            _syncLogMessage.value = result.message
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundHelper.release()
    }
}
