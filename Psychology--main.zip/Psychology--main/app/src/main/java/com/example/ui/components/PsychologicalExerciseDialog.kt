package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.TaskItem

@Composable
fun PsychologicalExerciseDialog(
    task: TaskItem,
    onSaveReflection: (taskId: Long, reflection: String) -> Unit,
    onDismiss: () -> Unit
) {
    var field1 by remember { mutableStateOf("") }
    var field2 by remember { mutableStateOf("") }
    var field3 by remember { mutableStateOf("") }

    val isGratitude = task.exerciseType == "GRATITUDE_3" || task.title.contains("Gratitude", ignoreCase = true)
    val isReframe = task.exerciseType == "COGNITIVE_REFRAME" || task.title.contains("Reframe", ignoreCase = true)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Morning Psychological Exercise",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.tertiary
                            )
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Dismiss")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Intro card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isGratitude) {
                            "Psychological grounding: Priming your neurochemistry early in the morning by consciously acknowledging positive anchors reduces anticipatory anxiety and boosts dopamine."
                        } else if (isReframe) {
                            "Cognitive Reframing (CBT): Identify a challenge or worry ahead today, and deliberately reframe your perspective toward agency, learning, and resilience."
                        } else {
                            "Set your psychological anchor for today. Clear conscious intentions direct subconscious problem-solving throughout the day."
                        },
                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Form inputs based on type
                if (isGratitude) {
                    Text(
                        text = "1. Someone or something you're grateful for:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = field1,
                        onValueChange = { field1 = it },
                        placeholder = { Text("e.g., A supportive friend or mentor...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gratitude_input_1"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "2. A simple sensory or environmental joy:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = field2,
                        onValueChange = { field2 = it },
                        placeholder = { Text("e.g., Warm morning coffee, the quiet dawn light...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gratitude_input_2"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "3. An opportunity you have today:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = field3,
                        onValueChange = { field3 = it },
                        placeholder = { Text("e.g., The chance to make progress on a project...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gratitude_input_3"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                } else if (isReframe) {
                    Text(
                        text = "Potential Stressor or Anticipatory Worry:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = field1,
                        onValueChange = { field1 = it },
                        placeholder = { Text("e.g., An upcoming difficult conversation or deadline...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reframe_stressor_input"),
                        shape = RoundedCornerShape(12.dp),
                        minLines = 2
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Constructive Cognitive Reframe (Agency & Opportunity):",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = field2,
                        onValueChange = { field2 = it },
                        placeholder = { Text("e.g., This is a chance to practice calm boundaries and clear communication...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reframe_solution_input"),
                        shape = RoundedCornerShape(12.dp),
                        minLines = 2
                    )
                } else {
                    Text(
                        text = "Your Early Morning Intention & Reflection:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = field1,
                        onValueChange = { field1 = it },
                        placeholder = { Text("e.g., Today I choose patience, presence, and focused effort...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("general_reflection_input"),
                        shape = RoundedCornerShape(12.dp),
                        minLines = 3
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            val combinedReflection = if (isGratitude) {
                                listOfNotNull(
                                    field1.takeIf { it.isNotBlank() }?.let { "1. $it" },
                                    field2.takeIf { it.isNotBlank() }?.let { "2. $it" },
                                    field3.takeIf { it.isNotBlank() }?.let { "3. $it" }
                                ).joinToString("\n").ifEmpty { "Completed 3 morning gratitudes." }
                            } else if (isReframe) {
                                listOfNotNull(
                                    field1.takeIf { it.isNotBlank() }?.let { "Challenge: $it" },
                                    field2.takeIf { it.isNotBlank() }?.let { "Reframe: $it" }
                                ).joinToString("\n").ifEmpty { "Completed cognitive reframe exercise." }
                            } else {
                                field1.ifBlank { "Completed morning psychological exercise." }
                            }

                            onSaveReflection(task.id, combinedReflection)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("save_reflection_button")
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save & Complete")
                    }
                }
            }
        }
    }
}
