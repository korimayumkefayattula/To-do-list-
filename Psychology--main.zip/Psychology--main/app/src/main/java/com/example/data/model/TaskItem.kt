package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TaskCategory(val displayName: String) {
    MORNING_ROUTINE("Morning Routine"),
    MEDITATION("Meditation"),
    PSYCHOLOGICAL("Psychological Exercise"),
    GENERAL("General"),
    WORK("Work & Focus"),
    HEALTH("Health & Body")
}

enum class TaskPriority {
    LOW,
    MEDIUM,
    HIGH
}

enum class SyncStatus {
    SYNCED,
    PENDING_SYNC,
    LOCAL_ONLY
}

@Entity(tableName = "tasks")
data class TaskItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val isCompleted: Boolean = false,
    val category: TaskCategory = TaskCategory.GENERAL,
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val dueDateEpochMs: Long? = null,
    val durationMinutes: Int = 5,
    val exerciseType: String? = null, // e.g. "BREATHING", "GRATITUDE_3", "COGNITIVE_REFRAME", "MORNING_INTENTION"
    val exerciseReflection: String? = null, // psychological reflections / notes
    val createdAtEpochMs: Long = System.currentTimeMillis(),
    val updatedAtEpochMs: Long = System.currentTimeMillis(),
    val syncStatus: SyncStatus = SyncStatus.PENDING_SYNC,
    val remoteId: String? = null,
    val isDeleted: Boolean = false // for soft deletion during sync
)
