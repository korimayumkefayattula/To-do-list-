package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.TaskItem
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE isDeleted = 0 ORDER BY isCompleted ASC, priority DESC, createdAtEpochMs DESC")
    fun getAllActiveTasks(): Flow<List<TaskItem>>

    @Query("SELECT * FROM tasks WHERE id = :id AND isDeleted = 0")
    fun getTaskById(id: Long): Flow<TaskItem?>

    @Query("SELECT * FROM tasks WHERE syncStatus = 'PENDING_SYNC'")
    suspend fun getPendingSyncTasks(): List<TaskItem>

    @Query("SELECT COUNT(*) FROM tasks WHERE syncStatus = 'PENDING_SYNC' AND isDeleted = 0")
    fun getPendingSyncCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE isDeleted = 0")
    fun getTotalTasksCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE isCompleted = 1 AND isDeleted = 0")
    fun getCompletedTasksCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<TaskItem>)

    @Update
    suspend fun updateTask(task: TaskItem)

    @Query("UPDATE tasks SET isDeleted = 1, syncStatus = 'PENDING_SYNC', updatedAtEpochMs = :timestamp WHERE id = :id")
    suspend fun softDeleteTask(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun hardDeleteTask(id: Long)

    @Query("UPDATE tasks SET syncStatus = 'SYNCED', updatedAtEpochMs = :syncTimestamp WHERE id IN (:ids)")
    suspend fun markTasksAsSynced(ids: List<Long>, syncTimestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM tasks WHERE isDeleted = 1 AND syncStatus = 'SYNCED'")
    suspend fun purgeDeletedSyncedTasks()
}
